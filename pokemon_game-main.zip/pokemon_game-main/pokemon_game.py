from pokemon import *
import random

class Game:
    def __init__(self):
        print("Welcome to The Pokemon World!")
        
    def main(self):
        self.read_files()
        self.party_size = 6


        self.party = []
        self.choose_party()
        self.choose_enemy_party()
        self.battle()
     

    def battle(self):
        enemy_deaths = 0
        user_deaths = 0
        user_death = False
        enemy_death = False
        self.active_poke_user = self.party[0]
        self.active_poke_enemy = self.enemy_party[0]
        while not (enemy_deaths == self.party_size or user_deaths == self.party_size):

            if user_death and not user_death == self.party_size:
                print("Your pokemon died, you switched in " + self.active_poke_user.get_name())
            elif enemy_death and not enemy_deaths == self.party_size:
                print("The enemy pokemon died, they switched in " + self.active_poke_enemy.get_name())

            user_death = False
            enemy_death = False
            
            while not (enemy_death or user_death):
                self.determine_priority()

                self.generate_health_bars(self.active_poke_user, self.active_poke_enemy)

                if self.turn == "user":
                    print("Your turn, please pick a move")
                    moves1 = self.active_poke_user.get_moves()
                    for move in moves1:
                        print(move.get_name())

                    move1 = None
                    in_list = False
                    while not in_list:
                        choice = input()
                        for move in moves1:
                            if move.get_name() == choice:
                                move1 = move
                                in_list = True
                                break
                        if not in_list:
                            print("Please pick one from the list")
                
                    moves2 = self.active_poke_enemy.get_moves()
                    selection = random.randint(0,3)
                    move2 = moves2[selection]

                    self.attack(self.active_poke_user, self.active_poke_enemy,move1)

                    if  self.active_poke_enemy.get_health() <= 0:
                        enemy_death = True
                        enemy_deaths += 1
                        if not enemy_deaths == self.party_size:
                            self.active_poke_enemy = self.enemy_party[enemy_deaths]
                        break
                    
                    self.attack(self.active_poke_enemy, self.active_poke_user,move2)
                    
                    if self.active_poke_user.get_health() <= 0:
                        user_death = True
                        user_deaths += 1
                        if not user_deaths == self.party_size:
                            self.active_poke_user = self.party[user_deaths]
                        break
                    
                else:
                    print("Your turn will be after, please pick a move")
                    moves2 = self.active_poke_user.get_moves()
                    for move in moves2:
                        print(move.get_name())

                    move2 = None
                    in_list = False
                    while not in_list:
                        choice = input()
                        for move in moves2:
                            if move.get_name() == choice:
                                move2 = move
                                in_list = True
                                break
                        if not in_list:
                            print("Please pick one from the list")
                            
                    moves1 = self.active_poke_enemy.get_moves()
                    selection = random.randint(0,3)
                    move1 = moves1[selection]
                    
                    self.attack(self.active_poke_enemy, self.active_poke_user,move1)
                    
                    if self.active_poke_user.get_health() <= 0:
                        user_death = True
                        user_deaths += 1
                        if not user_deaths == self.party_size:
                            self.active_poke_user = self.party[user_deaths]
                        break
                    
                    self.attack(self.active_poke_user, self.active_poke_enemy,move2)
                    
                    if  self.active_poke_enemy.get_health() <= 0:
                        enemy_death = True
                        enemy_deaths += 1
                        if not enemy_deaths == self.party_size:
                            self.active_poke_enemy = self.enemy_party[enemy_deaths]
                        break
        if user_deaths == self.party_size:
            print("You lost, better luck next time scrub")
        elif enemy_deaths == self.party_size:
            print("You won somehow, congratulations!")
                
    def attack(self, att_poke, def_poke, move):
        attack = 0
        defense = 0
        if move.get_move_type() == "Physical":
            attack = att_poke.get_stats()[1]
            defense = def_poke.get_stats()[2]
        elif move.get_move_type() == "Special":
            attack = att_poke.get_stats()[3]
            defense = def_poke.get_stats()[4]

        print(att_poke.get_name() + " attacked " + def_poke.get_name() + " with " + move.get_name() + "!")
        damage = (((22 * move.get_damage() * (attack/defense))/50)+2) * self.get_modifier(move, att_poke, def_poke)
        print("It did " + str(round(damage,0)) + " damage!")
        def_poke.damage(damage)
             
    def get_modifier(self, move, att_poke, def_poke):
        modifier = 1
        modifier *= self.get_move_mod(move, def_poke)

        if att_poke.get_type1() == move.get_name() or att_poke.get_type2() == move.get_name():
            modifier *= 1.5
        return modifier

    def get_move_mod(self, att_move, def_poke):
        ##print(att_move.get_type())
        modifier = 1
        att_index = self.find_move_index(att_move.get_type(), self.type_data)
        def_index1 = self.find_move_index(def_poke.get_type1(), self.type_data)

        def_index2 = 0
        if not def_poke.get_type2() == "None":
            def_index2 = self.find_move_index(def_poke.get_type2(), self.type_data)
            modifier *= self.type_effs[att_index][def_index2]

        modifier *= self.type_effs[att_index][def_index1]

        if modifier == 0:
            print("The other pokemon was immune to this move...")
        elif modifier == 0.25:
            print("The move was extremely unaffective")
        elif modifier == 0.5:
            print("The move was unaffective")
        elif modifier == 2:
            print("The move was very effective")
        elif modifier == 4:
            print("The move was super effective!")
        
        return modifier

    def generate_health_bars(self,poke1, poke2):
        bar = ""
        
        health1 = poke1.get_health()
        health1_prop = health1 / poke1.get_stats()[0]
        bar += poke1.get_name() + "  "
        for i in range(0, int(health1_prop * 10)):
            bar += "■"  
        if not (health1_prop == 1):
            for i in range(0,int((1 - health1_prop) * 10 + 1)):
                bar += "_"
        
        bar += "   " + str(round(poke1.get_health(),0)) + "/" + str(poke1.get_stats()[0]) + "\t"

        health2 = poke2.get_health()
        health2_prop = health2 / poke2.get_stats()[0]
        bar += poke2.get_name() + "  "
        for i in range(0, int(health2_prop * 10)):
            bar += "■"  
        if not (health2_prop == 1):
            for i in range(0,int((1 - health2_prop) * 10 + 1)):
                bar += "_"
        
        bar += "   " + str(round(poke2.get_health(),0)) + "/" + str(poke2.get_stats()[0])
        
        print(bar)

    def determine_priority(self):
        if self.active_poke_user.get_stats()[5] >= self.active_poke_enemy.get_stats()[5]:
            self.turn = "user"
        else:
            self.turn = "enemy"
        ##print(self.turn)

    def choose_party(self):
        ## Repeats for every party slot
        for i in range(1,self.party_size + 1):
            print("Choose pokemon number",i)
            
            self.possible_pokemon = self.pokemon_data
            
            print("    \t\tTypes:","\t\tMoves:")
            ## Display all possible pokemon 
            for pokemon in self.possible_pokemon:
                moves_string = pokemon[10] + ", " + pokemon[11] + ", " + pokemon[12] + ", " + pokemon[13]
                print(pokemon[0] + "    \t" + pokemon[1] + ", " + pokemon[2] + "\t" + moves_string)

            in_list = False
            ## While the current choice has not been found in the list, keep iterating until it is found
            ## When found, remove it from the possible list and break out
            ## If not found, remind the user to enter a pokemon from the list and try again
            while not in_list:
                choice = input()
                for pokemon in self.possible_pokemon:
                    if pokemon[0] == choice:
                        in_list = True
                        self.party.append(self.create_pokemon(pokemon[0]))
                        self.possible_pokemon.remove(pokemon)
                        break
                if not in_list:
                    print("Please pick one from the list")

        ## Print out final party details
        string = ""
        for pokemon in self.party:
            string += pokemon.get_name()+ ", "
        print("Your party is:",string)

    def choose_enemy_party(self):
        i = 0
        string = ""
        self.enemy_party = []
        ## Chooses a random pokemon from the available list and adds it to the enemy party
        while i < self.party_size:
            pokemon = self.possible_pokemon[random.randint(0,len(self.possible_pokemon) - 1)]
            self.enemy_party.append(self.create_pokemon(pokemon[0]))
            self.possible_pokemon.remove(pokemon)
            i+=1
            string += pokemon[0] + ", "
        
        print("Enemy party is:",string)


    def create_pokemon(self,name):
        pokemon = Pokemon(name)
        pokemon_index = self.find_index(name, self.pokemon_data)

        ## Read and initialize the level and types
        pokemon.set_level(int(self.pokemon_data[pokemon_index][3]))
        pokemon.set_types(self.pokemon_data[pokemon_index][1], self.pokemon_data[pokemon_index][2])

        ## Read and initialize the stats
        stats = []
        for i in range(4, 10):
            stats.append(int(self.pokemon_data[pokemon_index][i]))
        pokemon.set_stats(stats)

        ## Read the moves and set them for each pokemon with the correct damage, accuracy and pp
        moves = []
        for i in range(10, 14):
            move = Move(self.pokemon_data[pokemon_index][i])
            move_index = self.find_index(move.get_name(), self.move_data)

            move.set_type(self.move_data[move_index][1])
            move.set_move_type(self.move_data[move_index][2])

            move_stats = []
            for i in range(3,6):
                move_stats.append(int(self.move_data[move_index][i]))

            move.set_stats(move_stats)
            moves.append(move)
        pokemon.set_moves(moves)

        
        
        return pokemon
    
    def find_index(self, name, data):
        ## Find the index from the name
        i = 0
        while i < len(data):
            if data[i][0] == name:
                break
            i+=1

        return i

    def find_move_index(self, name, data):
        ## Find the index from the name
        i = 0
        while i < len(data):
            if data[i] == name:
                break
            i+=1

        return i

    def read_files(self):
        ## Initiate all the files
        pokemon_list = open("pokemonlist.txt", 'r')

        prelim_pokemon_data = pokemon_list.readlines()
        self.pokemon_data = []
        for data in prelim_pokemon_data:
            data = data.strip()
            entries = data.split(',')
            self.pokemon_data.append(entries)
        ##print(self.pokemon_data)
        
        move_list = open("movelist.txt", 'r')
        prelim_move_data = move_list.readlines()
        self.move_data = []
        for data in prelim_move_data:
            data = data.strip()
            entries = data.split(',')
            self.move_data.append(entries)
        ##print(self.move_data)

        type_IDs = open("type_IDs.txt", 'r').read()
        self.type_data = type_IDs.split(',')

        type_effectiveness_data = open("type_effectiveness.txt", 'r').readlines()
        self.type_effs = []
        for line in type_effectiveness_data:
            line = line.strip()
            data = line.split()

            temp_data = []
            for i in data:
                temp_data.append(float(i))
            self.type_effs.append(temp_data)
            


game = Game()
game.main()

    
    

    
