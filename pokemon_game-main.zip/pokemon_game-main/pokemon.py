from move import *

class Pokemon:
     
     def __init__(self, name,):
          self.name = name
          self.type1 = ""
          self.type2 = ""
          self.level = 0
          self.stats = [0, 0, 0, 0, 0, 0]
          self.moves = []
          self.health = 0

     def get_name(self):
          return self.name

     def get_type1(self):
          return self.type1

     def get_type2(self):
          return self.type2

     def get_level(self):
          return self.level

     def get_stats(self):
          return self.stats

     def get_moves(self):
          return self.moves

     def get_health(self):
          return self.health

     def display_details(self):
          print("Name:\t",self.get_name())
          print("Type 1:\t",self.get_type1())
          print("Type 2:\t",self.get_type2())
##          
##          stats = self.get_stats()
##          print("Attack:\t",stats[0])
##          print("Defense:",stats[1])
##          print("Stamina:",stats[2])

     def set_types(self, type1, type2):
          self.type1 = type1
          self.type2 = type2

     def set_level(self, level):
          self.level = level

     def set_stats(self, stats):
          self.stats = stats
          self.health = stats[0]

     def set_moves(self, moves):
          self.moves = moves

     def damage(self, damage):
          self.health -= damage
