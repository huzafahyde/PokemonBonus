class Move:

    def __init__(self, name):
        self.name = name
        self.type = ""
        self.move_type = ""
        self.damage = 0
        self.acc = 0
        self.pp = 0

    def get_name(self):
        return self.name

    def get_type(self):
        return self.type

    def get_move_type(self):
        return self.move_type

    def get_damage(self):
        return self.damage

    def get_acc(self):
        return self.acc

    def get_pp(self):
        return self.pp

    def set_type(self, typ):
        self.type = typ

    def set_move_type(self, move_type):
        self.move_type = move_type

    def set_stats(self, stats):
        self.damage = stats[0]
        self.acc = stats[1]
        self.pp = stats[2]
    
        
